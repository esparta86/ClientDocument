                      README
	              ======

	    M-MfileDocM API 1.0.1 release
	    ------------------------------

Welcome to the M-MfileDocM 1.0.1 release!  This release includes
versions of the M-MfileDocM implementation that create a 
documents

Please see the file at HOW TO USE Mitratech Mfile Document Massively.docx

JDK Version notes
-----------------
The M-MfileDocM 1.0.1 supports JDK 1.7 or higher.  Note that we have
currently tested this implementation with JDK 1.7


Execution
-----------------
How to execute : MfileClientDocuments.jar

1  unzip the rootMfileClientPerformance> file and put in c:\
2. If you need customize you must to change the local_setting.json
2. open a console cmd.exe
3. go to C:\rootMfileClientPerformance>
4. java -Xmx1024m -jar MfileClientDocuments.jar


Contents
--------
local_setting.json              is a file where user can customize and enter the informations,
                                which need to start.

mfile_setting_advanced.json :   sure of what you're doing, this file you have to set it up,
                                if in a modified version of the vault or IDs have changed the
								definition of properties