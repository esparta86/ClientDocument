package TOPLink.Private.Expressions;

import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import TOPLink.Private.DatabaseAccess.*;
import TOPLink.Private.Helper.*;
import TOPLink.Public.Exceptions.ValidationException;
import TOPLink.Public.Expressions.*;
import TOPLink.Public.Mappings.DatabaseMapping;
import TOPLink.Public.Mappings.DirectCollectionMapping;
import TOPLink.Public.Mappings.ManyToManyMapping;
import TOPLink.Public.PublicInterface.Descriptor;
import TOPLink.Public.PublicInterface.Session;
import TOPLink.Public.QueryFramework.ObjectLevelReadQuery;


// Referenced classes of package TOPLink.Private.Expressions:
//            SQLStatement, DataExpression, ExpressionIterator, ExpressionNormalizer, 
//            ExpressionSQLPrinter, FunctionExpression, ObjectExpression, QueryKeyExpression

public class SQLSelectStatement extends SQLStatement 
{

    protected Vector tables;
    protected Vector fields;
    protected short distinctState;
    protected Vector orderByExpressions;
    protected Vector groupByExpressions;
    protected short lockMode;
    protected Vector outerJoinedExpressions;
    protected Vector outerJoinedMappingCriteria;
    protected boolean isAggregateSelect;
    protected boolean requiresAliases;
    protected Hashtable tableAliases;
    protected transient DatabaseTable lastTable;
    protected transient DatabaseTable currentAlias;
    
    // Referenced classes of package TOPLink.Private.Expressions:
//  ExpressionIterator

    private final class A extends ExpressionIterator
    {

        public int counter;

        public void iterate(Expression expression)
        {
            counter = expression.assignTableAliasesStartingAt(counter);
        }


    }
    
    // Referenced classes of package TOPLink.Private.Expressions:
//  ExpressionIterator, QueryKeyExpression, SQLSelectStatement

    private final class B extends ExpressionIterator
    {

        public void iterate(Expression expression)
        {
            if(expression.isQueryKeyExpression() && ((QueryKeyExpression)expression).shouldQueryToManyRelationship() && !isDistinctComputed())
            {
                useDistinct();
            }
        }


    }



    public SQLSelectStatement()
    {
        fields = NonSynchronizedVector.newInstance(2);
        tables = NonSynchronizedVector.newInstance(4);
        lockMode = 0;
        requiresAliases = false;
        isAggregateSelect = false;
        distinctState = 0;
    }

    public void addField(DatabaseField databasefield)
    {
        getFields().addElement(databasefield);
    }

    public void addField(Expression expression)
    {
        if((expression instanceof FunctionExpression) && ((FunctionExpression)expression).getOperator().isAggregateOperator())
        {
            setIsAggregateSelect(true);
        }
        getFields().addElement(expression);
    }

    protected void addOrderByExpressionToSelectForDisticnt()
    {
        for(Enumeration enumeration = getOrderByExpressions().elements(); enumeration.hasMoreElements();)
        {
            Expression expression = (Expression)enumeration.nextElement();
            Expression expression1 = null;
            if(expression.isFunctionExpression() && expression.getOperator().isOrderOperator())
            {
                expression1 = ((FunctionExpression)expression).getBaseExpression();
            } else
            {
                expression1 = expression;
            }
            if(!getFields().contains(expression1))
            {
                getFields().addElement(expression1);
            }
        }

    }

    public void addTable(DatabaseTable databasetable)
    {
        if(!getTables().contains(databasetable))
        {
            getTables().addElement(databasetable);
        }
    }

    public void appendFromClauseToWriter(ExpressionSQLPrinter printer)
        throws IOException
    {
        Writer writer = printer.getWriter();
        Session session = printer.getSession();
        writer.write(" FROM ");
        boolean flag = true;
        
        boolean firstTable = true;
        boolean requiresEscape = false;//checks if the jdbc closing escape syntax is needed
        
        Vector outerJoinedAliases = NonSynchronizedVector.newInstance(1);
        if(!session.getPlatform().shouldPrintOuterJoinInWhereClause())
        {
            for(int index = 0; index < getOuterJoinExpressions().size(); index++)
            {
                QueryKeyExpression outerExpression = (QueryKeyExpression)getOuterJoinExpressions().elementAt(index);
                Helper.toDo("Cannot assume the first table, must figure out which talbes in the join criteria");
                /*DatabaseTable databasetable1 = (DatabaseTable)querykeyexpression.getMapping().getReferenceDescriptor().getTables().firstElement();
                DatabaseTable databasetable3 = (DatabaseTable)((ObjectExpression)querykeyexpression.getBaseExpression()).getDescriptor().getTables().firstElement();
                DatabaseTable databasetable4 = querykeyexpression.getBaseExpression().aliasForTable(databasetable3);
                DatabaseTable databasetable5 = querykeyexpression.aliasForTable(databasetable1);
                if(!vector.contains(databasetable4) && !vector.contains(databasetable5))
                {
                    if(!flag)
                    {
                        writer.write(", ");
                    }
                    if(session.getPlatform().shouldUseJDBCOuterJoinSyntax())
                    {
                        writer.write("{'oj ");
                    }
                    flag = false;
                    writer.write(databasetable3.getQualifiedName());
                    vector.addElement(databasetable4);
                    writer.write(" ");
                    writer.write(databasetable4.getQualifiedName());
                    writer.write(" LEFT OUTER JOIN ");
                    writer.write(databasetable1.getQualifiedName());
                    writer.write(" ");
                    vector.addElement(databasetable5);
                    writer.write(databasetable5.getQualifiedName());
                    writer.write(" ON ");
                    Expression expression = (Expression)outerJoinedMappingCriteria.elementAt(i);
                    expression.printSQL(expressionsqlprinter);
                    if(session.getPlatform().shouldUseJDBCOuterJoinSyntax())
                    {
                        writer.write("}");
                    }
                }*/
                
                DatabaseTable targetTable = null;
                DatabaseTable sourceTable = null;
                DatabaseTable sourceAlias = null;
                DatabaseTable targetAlias = null;
                if(outerExpression != null) {
                    if (outerExpression.getMapping().isDirectCollectionMapping()) {
                        targetTable = null;//((DirectCollectionMapping)outerExpression.getMapping()).getReferenceTable();
                    } else {
                        targetTable = (DatabaseTable)outerExpression.getMapping().getReferenceDescriptor().getTables().firstElement();
                    }
                    sourceTable = (DatabaseTable)((ObjectExpression)outerExpression.getBaseExpression()).getDescriptor().getTables().firstElement();
                    sourceAlias = outerExpression.getBaseExpression().aliasForTable(sourceTable);
                    targetAlias = outerExpression.aliasForTable(targetTable);
                } /*else {
                    sourceTable = (DatabaseTable)((ClassDescriptor)getDescriptorsForMultitableInheritanceOnly().get(index)).getTables().firstElement();
                    targetTable = (DatabaseTable)((ClassDescriptor)getDescriptorsForMultitableInheritanceOnly().get(index)).getInheritancePolicy().getChildrenTables().get(0);
                    Expression exp = (Expression)((Map)getOuterJoinedAdditionalJoinCriteria().elementAt(index)).get(targetTable);
                    sourceAlias = exp.aliasForTable(sourceTable);
                    targetAlias = exp.aliasForTable(targetTable);
                }*/

                if (!outerJoinedAliases.contains(targetAlias)) {
                    if (!outerJoinedAliases.contains(sourceAlias)) {
                        if (requiresEscape && session.getPlatform().shouldUseJDBCOuterJoinSyntax()) {
                            writer.write("}");
                        }

                        if (!firstTable) {
                            writer.write(",");
                        }

                        if (session.getPlatform().shouldUseJDBCOuterJoinSyntax()) {
                            //writer.write(session.getPlatform().getJDBCOuterJoinString());
                        }

                        requiresEscape = true;
                        firstTable = false;
                        flag = false;
                        writer.write(sourceTable.getQualifiedName());
                        outerJoinedAliases.addElement(sourceAlias);
                        writer.write(" ");
                        writer.write(sourceAlias.getQualifiedName());
                    }

                    /*if(outerExpression == null) {
                        printAdditionalJoins(printer, outerJoinedAliases, (ClassDescriptor)getDescriptorsForMultitableInheritanceOnly().get(index), (Map)getOuterJoinedAdditionalJoinCriteria().elementAt(index));
                    } else*/ if (outerExpression.getMapping().isDirectCollectionMapping()) {
                        // Append the join clause,
                        // If this is a direct collection, join to direct table.
                        Expression onExpression = (Expression)getOuterJoinedMappingCriteria().elementAt(index);

                        DatabaseTable newAlias = onExpression.aliasForTable(targetTable);
                        writer.write(" LEFT OUTER JOIN ");
                        writer.write(targetTable.getQualifiedName());
                        writer.write(" ");
                        outerJoinedAliases.addElement(newAlias);
                        writer.write(newAlias.getQualifiedName());
                        writer.write(" ON ");

                        //if (session.getPlatform() instanceof DB2MainframePlatform) {
                        //    ((RelationExpression)onExpression).printSQLNoParens(printer);
                        //} else {
                            onExpression.printSQL(printer);
                        //}

                        //Bug#4240751 Treat ManyToManyMapping separately for out join
                    } else if (outerExpression.getMapping().isManyToManyMapping()) {
                        // Must outerjoin each of the targets tables.
                        // The first table is joined with the mapping join criteria,
                        // the rest of the tables are joined with the additional join criteria.
                        // For example: EMPLOYEE t1 LEFT OUTER JOIN (PROJ_EMP t3 LEFT OUTER JOIN PROJECT t0 ON (t0.PROJ_ID = t3.PROJ_ID)) ON (t3.EMP_ID = t1.EMP_ID)
                        DatabaseTable relationTable = null;//((ManyToManyMapping)outerExpression.getMapping()).getRelationTable();
                        DatabaseTable relationAlias = ((Expression)getOuterJoinedMappingCriteria().elementAt(index)).aliasForTable(relationTable);
                        writer.write(" LEFT OUTER JOIN (");
                        
                        writer.write(relationTable.getQualifiedName());
                        writer.write(" ");
                        outerJoinedAliases.addElement(relationAlias);
                        writer.write(relationAlias.getQualifiedName());
                        
                        Vector tablesInOrder = NonSynchronizedVector.newInstance();//oracle.toplink.essentials.internal.helper.NonSynchronizedVector.newInstance(3);
                        tablesInOrder.add(sourceTable);
                        tablesInOrder.add(relationTable);
                        tablesInOrder.add(targetTable);
                        TreeMap indexToExpressionMap = new TreeMap();
                        mapTableIndexToExpression((Expression)getOuterJoinedMappingCriteria().elementAt(index), indexToExpressionMap, tablesInOrder);
                        Expression sourceToRelationJoin = (Expression)indexToExpressionMap.get(new Integer(1));
                        Expression relationToTargetJoin = (Expression)indexToExpressionMap.get(new Integer(2));
                        
                        writer.write(" JOIN ");
                        writer.write(targetTable.getQualifiedName());
                        writer.write(" ");
                        outerJoinedAliases.addElement(targetAlias);
                        writer.write(targetAlias.getQualifiedName());
                        writer.write(" ON ");
                        //if (session.getPlatform() instanceof DB2MainframePlatform) {
                        //    ((RelationExpression)relationToTargetJoin).printSQLNoParens(printer);
                        //} else {
                            relationToTargetJoin.printSQL(printer);
                        //}
                        
                        Map tablesJoinExpression = (Map)getOuterJoinedAdditionalJoinCriteria().elementAt(index);
                        if(tablesJoinExpression != null && !tablesJoinExpression.isEmpty()) {
                            printAdditionalJoins(printer, outerJoinedAliases, outerExpression.getMapping().getReferenceDescriptor(), tablesJoinExpression);
                        }
                        writer.write(") ON ");
                        //if (session.getPlatform() instanceof DB2MainframePlatform) {
                        //    ((RelationExpression)sourceToRelationJoin).printSQLNoParens(printer);
                        //} else {
                            sourceToRelationJoin.printSQL(printer);
                        //}
                    } else {
                        // Must outerjoin each of the targets tables.
                        // The first table is joined with the mapping join criteria,
                        // the rest of the tables are joined with the additional join criteria.
                        writer.write(" LEFT OUTER JOIN ");
                        Map tablesJoinExpression = getOuterJoinedAdditionalJoinCriteria().size() > index ? (Map)getOuterJoinedAdditionalJoinCriteria().elementAt(index) : null;
                        boolean hasAdditionalJoinExpressions = tablesJoinExpression != null && !tablesJoinExpression.isEmpty();
                        if(hasAdditionalJoinExpressions) {
                            writer.write(" (");
                        }
                        writer.write(targetTable.getQualifiedName());
                        writer.write(" ");
                        outerJoinedAliases.addElement(targetAlias);
                        writer.write(targetAlias.getQualifiedName());
                        if(hasAdditionalJoinExpressions) {
                            printAdditionalJoins(printer, outerJoinedAliases, outerExpression.getMapping().getReferenceDescriptor(), tablesJoinExpression);
                            writer.write(") ");
                        }
                        writer.write(" ON ");
                        Expression sourceToTargetJoin = (Expression)getOuterJoinedMappingCriteria().elementAt(index);
                        //if (session.getPlatform() instanceof DB2MainframePlatform) {
                        //    ((RelationExpression)sourceToTargetJoin).printSQLNoParens(printer);
                        //} else {
                            sourceToTargetJoin.printSQL(printer);
                        //}
                    }
                }
            }
           

        }
        for(Enumeration enumeration = getTableAliases().keys(); enumeration.hasMoreElements();)
        {
            DatabaseTable databasetable = (DatabaseTable)enumeration.nextElement();
            if(!outerJoinedAliases.contains(databasetable))
            {
                DatabaseTable databasetable2 = (DatabaseTable)getTableAliases().get(databasetable);
                if(requiresAliases())
                {
                    if(!flag)
                    {
                        writer.write(", ");
                    }
                    flag = false;
                    writer.write(databasetable2.getQualifiedName());
                    writer.write(" ");
                    writer.write(databasetable.getQualifiedName());
                } else
                {
                    writer.write(databasetable2.getQualifiedName());
                }
            }
        }

    }
    
    protected Vector outerJoinedAdditionalJoinCriteria;
    
    /**
     * INTERNAL:
     * Each Vector's element is a map of tables join expressions keyed by the tables
     */
    public Vector getOuterJoinedAdditionalJoinCriteria() {
        if (outerJoinedAdditionalJoinCriteria == null) {
            outerJoinedAdditionalJoinCriteria = NonSynchronizedVector.newInstance(3); //oracle.toplink.essentials.internal.helper.NonSynchronizedVector.newInstance(3);
        }

        return outerJoinedAdditionalJoinCriteria;
    }
    
    protected void printAdditionalJoins(ExpressionSQLPrinter printer, Vector outerJoinedAliases, Descriptor desc, Map tablesJoinExpressions)  throws IOException {
        Writer writer = printer.getWriter();
        Session session = printer.getSession();
        Vector descriptorTables = desc.getTables();
        int nDescriptorTables = descriptorTables.size();
        Vector tables;
        //if(desc.hasInheritance()) {
        //    tables = desc.getInheritancePolicy().getAllTables();
        //} else {
            tables = descriptorTables;
        //}

        // skip main table - start with i=1
        int tablesSize = tables.size();
        for(int i=1; i < tablesSize; i++) {
            DatabaseTable table = (DatabaseTable)tables.elementAt(i);
            Expression onExpression = (Expression)tablesJoinExpressions.get(table);
            if (onExpression != null) {
                if(i < nDescriptorTables) {
                    // it's descriptor's own table
                    writer.write(" JOIN ");
                } else {
                    // it's child's table
                    writer.write(" LEFT OUTER JOIN ");
                }
                writer.write(table.getQualifiedName());
                writer.write(" ");
                DatabaseTable alias = onExpression.aliasForTable(table);
                outerJoinedAliases.addElement(alias);
                writer.write(alias.getQualifiedName());
                writer.write(" ON ");
                //if (session.getPlatform() instanceof DB2MainframePlatform) {
                //    ((RelationExpression)onExpression).printSQLNoParens(printer);
                //} else {
                    onExpression.printSQL(printer);
                //}
            }
        }
    }

    /**
     * INTERNAL:
     * The method searches for expressions that join two tables each in a given expression.
     * Given expression and tablesInOrder and an empty SortedMap (TreeMap with no Comparator), this method
     *   populates the map with expressions corresponding to two tables 
     *     keyed by an index (in tablesInOrder) of the table with the highest (of two) index;
     *   returns all the participating in at least one of the expressions.
     * Example:
     *   expression (joining Employee to Project through m-m mapping "projects"):
     *     (employee.emp_id = proj_emp.emp_id) and (proj_emp.proj_id = project.proj_id)
     *   tablesInOrder:
     *     employee, proj_emp, project
     *     
     *   results:
     *     map: 
     *          1 -> (employee.emp_id = proj_emp.emp_id)
     *          2 -> (proj_emp.proj_id = project.proj_id)
     *     returned SortedSet: {0, 1, 2}.
     *     
     *     Note that tablesInOrder must contain all tables used by expression
     */
    protected static SortedSet mapTableIndexToExpression(Expression expression, SortedMap map, Vector tablesInOrder) {
        TreeSet tables = new TreeSet();
        if(expression instanceof DataExpression) {
            DataExpression de = (DataExpression)expression;
            if(de.getField() != null) {
                tables.add(new Integer(tablesInOrder.indexOf(de.getField().getTable())));
            }
        } else if(expression instanceof ParameterExpression) {
            ParameterExpression pe = (ParameterExpression)expression;
            if(pe.getField() != null) {
                tables.add(new Integer(tablesInOrder.indexOf(pe.getField().getTable())));
            }
        } else if(expression instanceof CompoundExpression) {
            CompoundExpression ce = (CompoundExpression)expression;
            tables.addAll(mapTableIndexToExpression(ce.getFirstChild(), map, tablesInOrder));
            tables.addAll(mapTableIndexToExpression(ce.getSecondChild(), map, tablesInOrder));
        } else if(expression instanceof FunctionExpression) {
            FunctionExpression fe = (FunctionExpression)expression;
            Iterator it = fe.getChildren().iterator();
            while(it.hasNext()) {
                tables.addAll(mapTableIndexToExpression((Expression)it.next(), map, tablesInOrder));
            }
        }
        
        if(tables.size() == 2) {
            map.put(tables.last(), expression);
        }
        
        return tables;
    }

    public void appendGroupByClauseToWriter(ExpressionSQLPrinter expressionsqlprinter)
        throws IOException
    {
        if(getGroupByExpressions().isEmpty())
        {
            return;
        }
        expressionsqlprinter.getWriter().write(" GROUP BY ");
        for(Enumeration enumeration = getGroupByExpressions().elements(); enumeration.hasMoreElements();)
        {
            Expression expression = (Expression)enumeration.nextElement();
            expression.printSQL(expressionsqlprinter);
            if(enumeration.hasMoreElements())
            {
                expressionsqlprinter.getWriter().write(", ");
            }
        }

    }

    public void appendOrderClauseToWriter(ExpressionSQLPrinter expressionsqlprinter)
        throws IOException
    {
        if(!hasOrderByExpressions())
        {
            return;
        }
        expressionsqlprinter.getWriter().write(" ORDER BY ");
        for(Enumeration enumeration = getOrderByExpressions().elements(); enumeration.hasMoreElements();)
        {
            Expression expression = (Expression)enumeration.nextElement();
            expression.printSQL(expressionsqlprinter);
            if(enumeration.hasMoreElements())
            {
                expressionsqlprinter.getWriter().write(", ");
            }
        }

    }

    protected int currentAliasNumber;
    
    public void assignAliases(Vector vector)
    {
//        _cls1 _lcls1 = new  Object()     /* anonymous class not found */
//    class _anm1 {}
//
//;
//        Expression expression;
//        for(Enumeration enumeration = vector.elements(); enumeration.hasMoreElements(); _lcls1.iterateOn(expression))
//        {
//            expression = (Expression)enumeration.nextElement();
//        }
        
        
        ExpressionIterator iterator = new ExpressionIterator() { 
            public void iterate(Expression each) { 
                currentAliasNumber = each.assignTableAliasesStartingAt(currentAliasNumber); 
            } 
        };
        
        for (Enumeration expressionEnum = vector.elements(); expressionEnum.hasMoreElements();) { 
            Expression expression = (Expression)expressionEnum.nextElement(); 
            iterator.iterateOn(expression); 
        } 

    }

    public SQLCall buildCall(Session session)
    {
        SQLCall sqlcall = new SQLCall();
        sqlcall.returnManyRows();
        CharArrayWriter chararraywriter = new CharArrayWriter(200);
        try
        {
            ExpressionSQLPrinter expressionsqlprinter = new ExpressionSQLPrinter(session, getTranslationRow(), sqlcall, requiresAliases());
            expressionsqlprinter.setRequiresDistinct(shouldDistinctBeUsed());
            expressionsqlprinter.setWriter(chararraywriter);
            chararraywriter.write("SELECT ");
            if(shouldDistinctBeUsed() && !isAggregateSelect())
            {
                chararraywriter.write("DISTINCT ");
            }
            sqlcall.setFields(writeFieldsIn(expressionsqlprinter));
            appendFromClauseToWriter(expressionsqlprinter);
            if(getWhereClause() != null)
            { 
                chararraywriter.write(" WHERE ");
                expressionsqlprinter.printExpression(getWhereClause());
            }
            if(getLockMode() == 1)
            {
                chararraywriter.write(session.getPlatform().getSelectForUpdateString());
            } else
            if(lockMode == 2)
            {
                chararraywriter.write(session.getPlatform().getSelectForUpdateNoWaitString());
            }
            if(hasGroupByExpressions())
            {
                appendGroupByClauseToWriter(expressionsqlprinter);
            }
            if(hasOrderByExpressions())
            {
                appendOrderClauseToWriter(expressionsqlprinter);
            }
            sqlcall.setSQLString(chararraywriter.toString());
            return sqlcall;
        }
        catch(IOException ioexception)
        {
            throw ValidationException.fileError(ioexception);
        }
    }

    public void computeDistinct()
    {
//        _cls2 _lcls2 = new  Object()     /* anonymous class not found */
//        class _anm2 {}
//
//;
//        if(getWhereClause() != null)
//        {
//            _lcls2.iterateOn(getWhereClause());
//        }
        
        ExpressionIterator iterator = new ExpressionIterator() { 
            public void iterate(Expression expression) { 
                if (expression.isQueryKeyExpression() && ((QueryKeyExpression)expression).shouldQueryToManyRelationship()) { 
                   // Aggregate should only use distinct as specified by the user. 
                   if (!isDistinctComputed()) { 
                       useDistinct(); 
                   } 
                } 
            } 
        };

        if (getWhereClause() != null) { 
            iterator.iterateOn(getWhereClause()); 
        } 

    }

    public void computeTables()
    {
        if(getWhereClause() == null && !hasOuterJoinExpressions())
        {
            computeTablesFromTables();
            return;
        }
        Hashtable hashtable;
        if(getWhereClause() == null)
        {
            hashtable = ((Expression)outerJoinedMappingCriteria.firstElement()).allAliasedTables();
        } else
        {
            hashtable = getWhereClause().allAliasedTables();
        }
        setTableAliases(hashtable);
        for(Enumeration enumeration = hashtable.elements(); enumeration.hasMoreElements(); addTable((DatabaseTable)enumeration.nextElement())) { }
    }

    public void computeTablesFromTables()
    {
        Hashtable hashtable = new Hashtable();
        for(int i = 0; i < getTables().size(); i++)
        {
            DatabaseTable databasetable = (DatabaseTable)getTables().elementAt(i);
            hashtable.put(new DatabaseTable("t" + (i + 1)), databasetable);
        }

        setTableAliases(hashtable);
    }

    public void dontUseDistinct()
    {
        setDistinctState((short)2);
    }

    public Vector getFields()
    {
        return fields;
    }

    public Vector getGroupByExpressions()
    {
        if(groupByExpressions == null)
        {
            groupByExpressions = NonSynchronizedVector.newInstance(3);
        }
        return groupByExpressions;
    }

    public short getLockMode()
    {
        return lockMode;
    }

    public Vector getOrderByExpressions()
    {
        if(orderByExpressions == null)
        {
            orderByExpressions = NonSynchronizedVector.newInstance(3);
        }
        return orderByExpressions;
    }

    public Vector getOuterJoinExpressions()
    {
        if(outerJoinedExpressions == null)
        {
            outerJoinedExpressions = NonSynchronizedVector.newInstance(3);
        }
        return outerJoinedExpressions;
    }

    public Vector getOuterJoinedMappingCriteria()
    {
        if(outerJoinedMappingCriteria == null)
        {
            outerJoinedMappingCriteria = NonSynchronizedVector.newInstance(3);
        }
        return outerJoinedMappingCriteria;
    }

    public Hashtable getTableAliases()
    {
        return tableAliases;
    }

    public Vector getTables()
    {
        return tables;
    }

    protected boolean hasAliasForTable(DatabaseTable databasetable)
    {
        if(tableAliases != null)
        {
            return getTableAliases().containsKey(databasetable);
        } else
        {
            return false;
        }
    }

    public boolean hasGroupByExpressions()
    {
        return groupByExpressions != null && !groupByExpressions.isEmpty();
    }

    public boolean hasOrderByExpressions()
    {
        return orderByExpressions != null && !orderByExpressions.isEmpty();
    }

    public boolean hasOuterJoinExpressions()
    {
        return outerJoinedExpressions != null && !outerJoinedExpressions.isEmpty();
    }

    public boolean isAggregateSelect()
    {
        return isAggregateSelect;
    }

    public boolean isDistinctComputed()
    {
        return distinctState != 0;
    }

    public void normalize(Session session, Descriptor descriptor)
    {
        if(getBuilder() == null)
        {
            setBuilder(new ExpressionBuilder());
        }
        getBuilder().setSession(session);
        if(!getBuilder().doesNotRepresentAnObjectInTheQuery() && descriptor != null && getBuilder().getQueryClass() == null)
        {
            getBuilder().setQueryClass(descriptor.getJavaClass());
        }
        Vector vector = new Vector();
        for(int i = 0; i < getFields().size(); i++)
        {
            Object obj = getFields().elementAt(i);
            if(obj instanceof Expression)
            {
                Expression expression1 = (Expression)obj;
                if(expression1.getBuilder() != super.builder)
                {
                    expression1 = expression1.rebuildOn(getBuilder());
                    getFields().setElementAt(expression1, i);
                }
                vector.addElement(expression1);
            }
        }

        if(hasGroupByExpressions())
        {
            for(int j = 0; j < getGroupByExpressions().size(); j++)
            {
                Expression expression2 = (Expression)getGroupByExpressions().elementAt(j);
                if(expression2.getBuilder() != super.builder)
                {
                    expression2 = expression2.rebuildOn(super.builder);
                    getGroupByExpressions().setElementAt(expression2, j);
                }
                vector.addElement(expression2);
            }

        }
        if(hasOrderByExpressions())
        {
            for(int k = 0; k < getOrderByExpressions().size(); k++)
            {
                Expression expression3 = (Expression)getOrderByExpressions().elementAt(k);
                if(expression3.getBuilder() != super.builder)
                {
                    expression3 = expression3.rebuildOn(super.builder);
                    getOrderByExpressions().setElementAt(expression3, k);
                }
                vector.addElement(expression3);
            }

        }
        Expression expression = getWhereClause();
        ExpressionNormalizer expressionnormalizer = new ExpressionNormalizer(this);
        Expression expression4 = null;
        if(expression != null)
        {
            expression4 = expression.normalize(expressionnormalizer);
        }
        for(int l = 0; l < vector.size(); l++)
        {
            Expression expression5 = (Expression)vector.elementAt(l);
            expression5.normalize(expressionnormalizer);
        }

        if(expression4 == null)
        {
            setWhereClause(expressionnormalizer.getAdditionalExpression());
        } else
        {
            setWhereClause(expression4.and(expressionnormalizer.getAdditionalExpression()));
        }
        if(getWhereClause() != null)
        {
            vector.addElement(getWhereClause());
        }
        if(hasOuterJoinExpressions())
        {
            Helper.addAllToVector(vector, getOuterJoinedMappingCriteria());
        }
        if(getWhereClause() != null)
        {
            getWhereClause().validate();
        }
        assignAliases(vector);
        if(descriptor == null)
        {
            computeTablesFromTables();
        } else
        {
            computeTables();
        }
        if(shouldDistinctBeUsed() && hasOrderByExpressions())
        {
            addOrderByExpressionToSelectForDisticnt();
        }
    }

    public void normalizeForView(Session session, Descriptor descriptor)
    {
        if(getWhereClause() != null)
        {
            ExpressionBuilder expressionbuilder = getWhereClause().getBuilder();
            expressionbuilder.setViewTable((DatabaseTable)getTables().firstElement());
        }
        normalize(session, descriptor);
    }

    public void removeField(DatabaseField databasefield)
    {
        getFields().removeElement(databasefield);
    }

    public void removeTable(DatabaseTable databasetable)
    {
        getTables().removeElement(databasetable);
    }

    public boolean requiresAliases()
    {
        if(requiresAliases)
        {
            return true;
        }
        if(tableAliases != null)
        {
            return getTableAliases().size() > 1;
        } else
        {
            return false;
        }
    }

    public void resetDistinct()
    {
        setDistinctState((short)0);
    }

    public void setDistinctState(short word0)
    {
        distinctState = word0;
    }

    public void setFields(Vector vector)
    {
        fields = vector;
    }

    public void setGroupByExpressions(Vector vector)
    {
        groupByExpressions = vector;
    }

    public void setIsAggregateSelect(boolean flag)
    {
        isAggregateSelect = flag;
    }

    public void setLockMode(short word0)
    {
        lockMode = word0;
    }

    public void setOrderByExpressions(Vector vector)
    {
        orderByExpressions = vector;
    }

    public void setOuterJoinExpressions(Vector vector)
    {
        outerJoinedExpressions = vector;
    }

    public void setOuterJoinedMappingCriteria(Vector vector)
    {
        outerJoinedMappingCriteria = vector;
    }

    public void setRequiresAliases(boolean flag)
    {
        requiresAliases = flag;
    }

    protected void setTableAliases(Hashtable hashtable)
    {
        tableAliases = hashtable;
    }

    public void setTables(Vector vector)
    {
        tables = vector;
    }

    public boolean shouldDistinctBeUsed()
    {
        return distinctState == 1;
    }

    public void useDistinct()
    {
        setDistinctState((short)1);
    }

    protected void writeField(ExpressionSQLPrinter expressionsqlprinter, DatabaseField databasefield)
    {
        if(expressionsqlprinter.isFirstElementPrinted())
        {
            expressionsqlprinter.printString(", ");
        } else
        {
            expressionsqlprinter.setIsFirstElementPrinted(true);
        }
        if(expressionsqlprinter.shouldPrintQualifiedNames())
        {
            if(databasefield.getTable() != lastTable)
            {
                lastTable = databasefield.getTable();
                currentAlias = getBuilder().aliasForTable(lastTable);
                if(currentAlias == null)
                {
                    currentAlias = lastTable;
                }
            }
            expressionsqlprinter.printString(currentAlias.getQualifiedName());
            expressionsqlprinter.printString(".");
            expressionsqlprinter.printString(databasefield.getName());
        } else
        {
            expressionsqlprinter.printString(databasefield.getName());
        }
    }

    protected void writeFieldsFromExpression(ExpressionSQLPrinter expressionsqlprinter, Expression expression, Vector vector)
    {
        expression.writeFields(expressionsqlprinter, vector, this);
    }

    protected Vector writeFieldsIn(ExpressionSQLPrinter expressionsqlprinter)
    {
        lastTable = null;
        Vector vector = NonSynchronizedVector.newInstance();
        for(Enumeration enumeration = getFields().elements(); enumeration.hasMoreElements();)
        {
            Object obj = enumeration.nextElement();
            if(obj instanceof Expression)
            {
                writeFieldsFromExpression(expressionsqlprinter, (Expression)obj, vector);
            } else
            {
                writeField(expressionsqlprinter, (DatabaseField)obj);
                vector.addElement(obj);
            }
        }

        return vector;
    }

}
